package Factory;

public class ConcreteProduct2 implements Product {

    @Override
    public void getInfo() {
        System.out.print("This one is product numba #2!");
    }
}
