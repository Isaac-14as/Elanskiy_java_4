package Factory;

public interface Product {
    void getInfo();
}
