package AbstractFactory;

public class ProductAB implements AbstractProductA {
    public ProductAB() {
        System.out.println("This product is A with style B");
    }
}
