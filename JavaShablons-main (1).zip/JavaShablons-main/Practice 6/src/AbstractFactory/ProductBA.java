package AbstractFactory;

public class ProductBA implements AbstractProductB {
    public ProductBA() {
        System.out.println("This product is B with style A");
    }
}
