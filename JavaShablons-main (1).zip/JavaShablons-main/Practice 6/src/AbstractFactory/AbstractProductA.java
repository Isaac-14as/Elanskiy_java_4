package AbstractFactory;

public interface AbstractProductA {



}
