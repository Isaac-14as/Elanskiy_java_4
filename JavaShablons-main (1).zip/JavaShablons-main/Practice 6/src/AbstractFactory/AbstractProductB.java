package AbstractFactory;

public interface AbstractProductB {



}
