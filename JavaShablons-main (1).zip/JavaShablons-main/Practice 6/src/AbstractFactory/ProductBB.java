package AbstractFactory;

public class ProductBB implements AbstractProductB {
    public ProductBB() {
        System.out.println("This product is B with style B");
    }
}
