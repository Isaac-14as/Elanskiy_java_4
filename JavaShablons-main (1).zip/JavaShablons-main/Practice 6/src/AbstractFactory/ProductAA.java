package AbstractFactory;

public class ProductAA implements AbstractProductA {
    public ProductAA() {
        System.out.println("This product is A with style A");
    }
}
