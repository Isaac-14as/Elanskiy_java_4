package Prototype;

public interface Prototype<T> {
    T clone();
}
