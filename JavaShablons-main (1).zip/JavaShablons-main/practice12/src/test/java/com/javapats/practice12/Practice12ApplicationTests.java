package com.javapats.practice12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice12ApplicationTests {

    @Test
    void contextLoads() {
    }

}
