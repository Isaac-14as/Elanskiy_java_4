package State;

public class StateTest {
    public static void main(String[] args) {
        Context context = new Context();
        context.request();
        context.request();
    }
}
