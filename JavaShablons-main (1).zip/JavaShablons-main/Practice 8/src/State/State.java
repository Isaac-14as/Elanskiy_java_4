package State;

public interface State {

    void handle(Context context);

}
