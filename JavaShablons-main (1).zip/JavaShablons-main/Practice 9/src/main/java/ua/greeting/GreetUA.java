package ua.greeting;

public class GreetUA {

    public static void main(String[] args) {

        System.out.println("Budymo Hey! My name id ALEXEY!");

    }

}
