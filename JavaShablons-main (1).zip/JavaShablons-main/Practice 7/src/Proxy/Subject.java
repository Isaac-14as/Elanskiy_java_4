package Proxy;

public interface Subject {

    void request();

}
