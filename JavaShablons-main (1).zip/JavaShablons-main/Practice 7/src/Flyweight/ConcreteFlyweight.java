package Flyweight;

public class ConcreteFlyweight {
}
