package Flyweight;

public interface Flyweight {
}
