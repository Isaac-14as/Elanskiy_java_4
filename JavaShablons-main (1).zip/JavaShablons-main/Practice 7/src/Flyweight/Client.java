package Flyweight;

public class Client {

    

}
