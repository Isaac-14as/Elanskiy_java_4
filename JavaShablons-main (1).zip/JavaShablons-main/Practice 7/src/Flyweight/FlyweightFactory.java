package Flyweight;

public class FlyweightFactory {
}
