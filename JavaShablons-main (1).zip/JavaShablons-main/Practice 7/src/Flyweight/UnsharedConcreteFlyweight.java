package Flyweight;

public class UnsharedConcreteFlyweight {
}
