package com.javapatsq.practice11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice11ApplicationTests {

    @Test
    void contextLoads() {
    }

}
