package com.javapats.practice10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice10ApplicationTests {

    @Test
    void contextLoads() {
    }

}
