package com.javapats.practice10.entities;

import org.springframework.stereotype.Component;

@Component
public interface Fighter {
    void doFight();
}
